/*
5) Escreva um programa que inverta os caracteres de um string.

IMPORTANTE:
a) Essa string pode ser informada atrav�s de qualquer entrada de sua prefer�ncia ou pode ser previamente definida no c�digo;
b) Evite usar fun��es prontas, como, por exemplo, reverse;
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{

	char string[21], reverso[21]; 
	int i=0, j=0, p=0;
	
	printf("Digite uma palavra: ");
	gets(string);
	
	for(i ; i < strlen(string) ; i++)
	{
		if( string[i] != '\0')
		{
			j++;
		}
	}
	
	j=j-1;
	
	for(i ; i > 0; i--)
	{
		reverso[p] = string[j];
		j--;
		p++;
	}

	printf("\n%s", reverso);
	
	return 0;	
}
