/* 
4) Dado o valor de faturamento mensal de uma distribuidora, detalhado por estado:

SP � R$67.836,43
RJ � R$36.678,66
MG � R$29.229,88
ES � R$27.165,48
Outros � R$19.849,53

Escreva um programa na linguagem que desejar onde calcule o percentual de representa��o 
que cada estado teve dentro do valor total mensal da distribuidora.
*/

#include<stdio.h>
int main ()
{
	double sp=67836.43, rj=36678.66, mg=29229.88, es=27165.48, ou=19849.53, total;
	
	total = sp+rj+mg+es+ou;
	
	printf("\ntotal = %.2lf\n\nSP = %.2lf%%\nRJ = %.2lf%%\nMG = %.2lf%%\nES = %.2lf%%\nOUTROS = %.2lf%%", total, sp/(total/100), rj/(total/100), mg/(total/100), es/(total/100), ou/(total/100));
	
	return 0;
}
